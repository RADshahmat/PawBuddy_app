import 'package:flutter/material.dart';
import '../../../widgets/premium_feature_card.dart';
import '../../../widgets/animated_card.dart';
import '../../../models/user_model.dart';
import '../../../utils/app_colors.dart';
import '../../features/vet_directory/vet_directory_screen.dart';
import '../../features/volunteer/volunteer_screen.dart';
import '../../features/food_store/food_store_screen.dart';
import '../../features/education/education_screen.dart';
import '../../features/rewards/rewards_screen.dart';
import '../../features/vetbot/vetbot_screen.dart';
import '../../features/leaderboard/leaderboard_screen.dart';
import '../../features/pet_sitting/pet_sitting_screen.dart';

class FeatureGrid extends StatelessWidget {
  final UserModel user;

  const FeatureGrid({Key? key, required this.user}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 1.1,
        children: [
          // Premium Features
          PremiumFeatureCard(
            title: 'Vet Directory',
            icon: Icons.local_hospital_rounded,
            color: AppColors.error,
            screen: VetDirectoryScreen(),
          ),
          PremiumFeatureCard(
            title: 'Volunteer',
            icon: Icons.volunteer_activism_rounded,
            color: AppColors.success,
            screen: VolunteerScreen(),
          ),
          PremiumFeatureCard(
            title: 'Education',
            icon: Icons.school_rounded,
            color: AppColors.primary,
            screen: EducationScreen(),
          ),
          PremiumFeatureCard(
            title: 'VetBot',
            icon: Icons.chat,
            color: AppColors.primaryLight,
            screen: VetBotScreen(),
          ),
          PremiumFeatureCard(
            title: 'Pet Shelter',
            icon: Icons.night_shelter,
            color: AppColors.accentLight,
            screen: PetSittingScreen(),
          ),
          PremiumFeatureCard(
            title: 'Rewards',
            icon: Icons.card_giftcard_rounded,
            color: AppColors.warning,
            screen: RewardsScreen(),
          ),
          PremiumFeatureCard(
            title: 'Leaderboard',
            icon: Icons.leaderboard_rounded,
            color: AppColors.accent,
            screen: LeaderboardScreen(),
          ),

          // Free Feature
          _buildFreeFeatureCard(
            context,
            'Animal Accessories',
            Icons.restaurant_rounded,
            [AppColors.secondary, AppColors.secondaryLight],
            FoodStoreScreen(),
          ),
        ],
      ),
    );
  }

  Widget _buildFreeFeatureCard(
      BuildContext context,
      String title,
      IconData icon,
      List<Color> colors,
      Widget screen,
      ) {
    return AnimatedCard(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => screen),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: colors,
          ),
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: colors.first.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 30,
                color: Colors.white,
              ),
              const SizedBox(height: 8),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
